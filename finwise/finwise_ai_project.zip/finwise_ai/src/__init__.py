"""FinWise AI source package."""
